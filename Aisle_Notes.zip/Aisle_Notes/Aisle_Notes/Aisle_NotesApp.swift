//
//  Aisle_NotesApp.swift
//  Aisle_Notes
//
//  Created by Asif Habib on 16/07/25.
//

import SwiftUI

@main
struct Aisle_NotesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
