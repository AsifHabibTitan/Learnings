//
//  Onboarding_2_0App.swift
//  Onboarding-2.0
//
//  Created by Asif Habib on 22/10/25.
//

import SwiftUI

@main
struct Onboarding_2_0App: App {
    var body: some Scene {
        WindowGroup {
            WeightSelector()
        }
    }
}
